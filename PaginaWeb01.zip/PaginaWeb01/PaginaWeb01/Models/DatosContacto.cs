﻿namespace PaginaWeb01.Models
{
    public class DatosContacto
    {
        public string Nombre { get; set; }
        public string Correo { get; set; }
        public string Comentario { get; set; }
    }
}
