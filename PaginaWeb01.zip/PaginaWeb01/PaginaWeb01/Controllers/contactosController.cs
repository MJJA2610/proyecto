﻿using Microsoft.AspNetCore.Mvc;

using PaginaWeb01.Models;


namespace PaginaWeb01.Controllers
{
    public class contactosController : Controller
    {
        List<DatosContacto> datos = new List<DatosContacto>()
{ new DatosContacto(){Correo="rmonge@ui.edu",
Nombre="Ricardo"},
new DatosContacto(){Correo="karim@ui.edu",
Nombre="Karim"},
new DatosContacto(){Correo="fabi@ui.edu",
Nombre="Fabiola"}
};

        public IActionResult Index()
        {
            return View(datos);
        }
    }
}
