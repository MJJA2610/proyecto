﻿using Microsoft.AspNetCore.Mvc;
using PaginaWeb01.Models;
using System.Diagnostics;

namespace PaginaWeb01.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Contactanos()
        {
            DatosContacto dc = new DatosContacto();
            dc.Nombre = "Maria Jose Jimenez";
            dc.Correo = "mariajosejimenezarce1999@gmail.com";
            dc.Comentario = "Es muy chiva.";
            return View(dc);
        }
        public IActionResult Privacy()
        {
            return View();
        }
        // atributo del metodo, solo es cuando envio en formulario.
        [HttpPost]
        public IActionResult Contactanos(DatosContacto dc)
        {
            dc.Comentario = "Comentario Genérico";
            return View("ContactanosGracias", dc);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}